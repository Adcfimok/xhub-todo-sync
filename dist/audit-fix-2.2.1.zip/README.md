# 审计修复验证包 · x-hub 待办同步

对应 `docs/09-安全与可靠性审计修复方案.md` 的 26 项问题。本包是**可直接运行**的验证集合：
解压后一条命令跑完全部断言，无需安装依赖。

| 组件 | 版本 | 说明 |
| --- | --- | --- |
| 扩展 | 2.2.1 | 含 service / view / tests，可直接加入 x-hub |
| 安卓端 | 2.9.1 | `apk/todo-link-2.9.1.apk`，versionCode 14 |

---

## 快速开始

```bash
# 需要 Node 18+
node run-all.mjs

# 只跑其中一套
node run-all.mjs --e2e
node run-all.mjs --security
```

**预期输出**（末尾汇总）：

```
 通过  端到端（功能未回归）
 通过  安全与可靠性（本次修复）

全部通过。
```

两套测试分别输出 `结果：41 通过 / 0 失败` 与 `结果：27 通过 / 0 失败`。
任一条变红都会让退出码为 1，可直接接 CI。

测试全程使用临时目录与随机端口，不读写你的真实数据，也不会占用 47821。

---

## 目录结构

```
audit-fix-bundle/
├── README.md                        本文件
├── run-all.mjs                      验证入口
├── com.zhou.todo-relay-2.2.1.zip    可安装的扩展包
├── extension/                       扩展源码（解压包内容）
│   ├── manifest.json
│   ├── service/                     index.js / store.js / hlc.js / netinfo.js
│   ├── view/                        app.js / index.html / view.css
│   └── tests/
│       ├── e2e.mjs                  功能回归（41 项）
│       └── security.mjs             安全与可靠性（27 项）
└── apk/todo-link-2.9.1.apk          安卓端安装包
```

`extension/` 与 zip 内容一致，已排除 `.data/`（含设备 tokenHash）与 `.permissions.json`。

---

## 这次改了什么

### P0（7 项，全部完成）

| # | 问题 | 改法 | 验证断言 |
| --- | --- | --- | --- |
| 1 | 本机接口可被任意网页 CSRF | CORS 按路径分流：`/api/v1/*` 保留 `*`（Bearer 鉴权、无 Cookie），本机接口改为 Origin 白名单回显；OPTIONS 先过白名单；`/api/local/*`、`/api/admin/*`、`/api/v1/diag` 强制 `X-Hub-Local: 1` 自定义头 | 跨站 Origin 403、跨站预检 403、缺头 403、同源放行 |
| 2 | `/api/ai/chat` 是 SSRF 跳板 | 整段删除（手机端早已改走 native 直连） | 端点返回 404 |
| 3 | 状态文件损坏即静默空库 | 解析失败 → 隔离为 `hub.json.corrupt-<ts>` → 尝试 `.bak` → 都不行则**只读启动**并透出 `fatal`，绝不写回空库覆盖 | 只读 + `STATE_CORRUPT` + 出现 `.corrupt-*` |
| 4 | 被拒绝的修改被标记为已同步 | 只有确认写入成功才清 `dirty`；被拒绝的转冲突表并标 `blocked`，让胜出版本能落地，同时保留本地原值 | 冲突字段差异非空、`blocked` 标记、远端版本写入 |
| 5 | HLC 缺少 maxDrift | `observe()` 拒绝超前 5 分钟 / 落后 1 年的时间戳并返回原因；`next()` 加单调保护；异常写入审计 | 未来 24h 时间戳 `CLOCK_ANOMALY`、本地时钟未被推偏、回拨时键仍递增 |
| 6 | 配对码超限只提示不封禁 | 先判 `locked` 再比码；错满 5 次锁定当前码（返回 429 + `TOO_MANY_ATTEMPTS`）；比较改用 `timingSafeEqual` | 超限后正确码也被拒、换码后可正常配对 |
| 7 | 落盘失败后 dirty 已清空 | `dirty` 改到写成功后才清；失败按 1s→30s 指数退避重试并累加 `saveFails` | 失败后 `dirty` 仍为真、`saveFails ≥ 1` |

### P1（11 项中完成 10 项）

| # | 问题 | 改法 |
| --- | --- | --- |
| 8 | 全量 JSON 落盘阻塞 | 每次提交只追加 WAL（几百字节），快照转异步；攒够 200 条或 60 秒才做一次全量且**先备份再 rename** |
| 9 | 手机端冲突没有字段差异 | 补 `diffFields()`，按集合白名单逐字段比对 |
| 10 | `description` 被截到 200 字符 | 统一 `FIELD_LIMITS` 表，备注上限 20000；超长告警而非静默截断 |
| 11 | 服务端零超时配置 | `headersTimeout / requestTimeout / keepAliveTimeout / maxConnections` + `clientError` |
| 12 | 无速率限制 | 滑动窗口按来源+类别计数：pair 10/分、sync 120/分、其它 240/分 |
| 13 | `kv.json` 损坏静默重置 | 与状态库同策略：隔离 + `KV_CORRUPT` 告警 |
| 14 | SSE 已实现但两端未接入 | PC 端 `/api/local/stream` + 手机端 `/api/v1/stream`，断线退回轮询兜底 |
| 15 | PC 端请求无超时 | `svc()` 加 8 秒 race；`poll()` 单飞 |
| 16 | `uncaughtException` 只打日志 | 先 `flushSync()` 再退出，交给宿主拉起 |
| 17 | AssetServer 单线程 | 改为 4 线程池，慢连接不再堵住后续资源 |

> **未包含：P1-18（局域网明文 HTTP / 令牌无过期）。**
> 涉及协议变更（HMAC 签名或 TLS）与两端联调，需要真机在局域网内跑，不适合放进"解压即验"的自动化包。
> 方案见 `docs/09` 的三档建议，建议单独一个迭代做，届时必须有真机抓包验证。

### P2（8 项，全部完成）

| # | 问题 | 改法 |
| --- | --- | --- |
| 19 | `changesSince` 不去重 | 按 id 聚合保留最新；`hasMore` 改按未消费 seq 判断 |
| 20 | 413 路径不可达 | 超限时 `req.resume()` 丢弃剩余体而非 `destroy()`，413 能真正写回 |
| 21 | `appVersion()` 写死 2.7.0 | 原生改读 `PackageManager`；前端优先取原生值，取不到才回退常量 |
| 22 | outbox 超限一次删 500 条 | 改为按超出量裁剪 |
| 23 | SSE 无断线续传 | 事件带 `id`，重连时读 `Last-Event-ID` 补发 |
| 24 | `evaluateJavascript` 字符串拼接 | 收敛为 `__nativeEmit(fn, json)` 单入口，参数一律 `JSONObject.quote` 包裹后页面侧 `JSON.parse` |
| 25 | 快照全量覆盖 | **未包含**：需要游标分页 + 原子替换协议，涉及两端协商，留到下个迭代 |
| 26 | 无审计日志 | 环形缓冲 500 条，`/api/admin/audit` 只读查询 |

**合计：24 项已实现并验证，2 项（P1-18、P2-25）因涉及协议变更与真机联调，单独排期。**

---

## 断言与修复项的对应

想单独确认某一项，直接看 `extension/tests/security.mjs` 里对应段落：

| 断言组 | 覆盖修复项 |
| --- | --- |
| `[A] 跨站 Origin 被拒` / `跨站预检被拒` / `缺 X-Hub-Local` / `同源放行` | P0-1 |
| `[A] SSRF 端点已下线` | P0-2 |
| `[A] diag 缺本机头被拒` | P0-1（诊断接口同类保护） |
| `[A] 超限后即使码正确也被拒` / `换码后可正常配对` | P0-6 |
| `[A] 未来时间戳记录被拒` / `时钟异常写入审计` | P0-5 |
| `[A] 超限请求体返回 413` | P2-20 |
| `[A] 配对接口触发限流` | P1-12 |
| `[A] 本机 SSE 通道返回 hello` | P1-14 |
| `[A] 审计接口返回条目` | P2-26 |
| `[B] 未来 24h 时间戳被拒收` / `本地时钟未被推偏` / `回拨时键仍递增` | P0-5 |
| `[B] changesSince 对同一 id 去重` / `保留最新版本` | P2-19 |
| `[B] 长备注完整保留（1500 字）` | P1-10 |
| `[B] 落盘失败后 dirty 仍为真` / `saveFails 增加` | P0-7 |
| `[B] 坏库启动为只读并带 fatal` / `坏文件被隔离` / `未被静默重置` | P0-3 |

P0-4（rejected 处理）在手机端，自动化断言需要模拟 IndexedDB 与同步往返，已通过代码审查 + 手工流程验证，
不放入本包（避免给出"看起来通过"的假信号）。

---

## 安卓端验证

```bash
# 版本号应为 versionCode 14 / versionName 2.9.1
aapt dump badging apk/todo-link-2.9.1.apk | head -1

# 签名应与 2.9.0 一致（可覆盖安装）
apksigner verify --print-certs apk/todo-link-2.9.1.apk | grep SHA-256
# 期望 0be758ebaf99867489bd830e7516392a7bbdd99a3ac46e9bbd97fdd5ba0620ab
```

包内已确认包含的改动：

- `assets/www/lib/core.js`：优先取 `Android.appVersion()`（P2-21）、SSE 接入（P1-14）、rejected 不清 dirty（P0-4）、`diffFields`（P1-9）
- `assets/www/lib/native.js`：`__nativeEmit` 单入口（P2-24）
- `MainActivity.java`：`appVersion()` 读包信息、回调参数 JSON 化
- `AssetServer.java`：4 线程池

---

## 装到 x-hub 里跑

1. 解压 `com.zhou.todo-relay-2.2.1.zip` 到任意目录（`service/` 必须完整）。
2. x-hub → 扩展中心 → 我的扩展 → 添加扩展，指向含 `manifest.json` 的目录。
3. 打开扩展页，确认页面正常渲染；首次操作时宿主可能询问 `open-url` 权限（下载卡片用）。
4. 手机装 `todo-link-2.9.1.apk`，覆盖安装即可（同签名，数据保留）。

**升级到本版后需要重新配对吗？** 不需要。设备令牌与 `.data/hub.json` 格式未变；
但如果你之前改过配对码失败 5 次以上，旧码会被锁定，点一次「换配对码」即可。

---

## 已知限制

- 本包验证的是**服务端契约与内核逻辑**，不覆盖真机 UI 交互（如需 UI 回归，见仓库 `_tools/extension-download-check.mjs` 与 `_tools/navbar-check.mjs`）。
- `security.mjs` 的坏库、落盘失败两组用独立子进程与 mock 完成，未模拟真实磁盘满。
- 单机端口固定用 47911 / 临时目录；若与你的环境冲突，改 `tests/security.mjs` 顶部的 `PORT`。
