#!/usr/bin/env node
/**
 * 审计修复验证入口：跑完两套测试并汇总。
 *
 *   node run-all.mjs            全量（端到端 + 安全可靠性）
 *   node run-all.mjs --e2e      只跑端到端
 *   node run-all.mjs --security 只跑安全可靠性
 *
 * 退出码：两套都通过为 0，否则 1。
 */

import { spawnSync } from 'node:child_process'
import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const TESTS = path.join(HERE, 'extension', 'tests')

const args = new Set(process.argv.slice(2))
const onlyE2e = args.has('--e2e')
const onlySecurity = args.has('--security')
const runBoth = !onlyE2e && !onlySecurity

const suites = []
if (runBoth || onlyE2e) {
  suites.push({ name: '端到端（功能未回归）', file: path.join(TESTS, 'e2e.mjs') })
}
if (runBoth || onlySecurity) {
  suites.push({ name: '安全与可靠性（本次修复）', file: path.join(TESTS, 'security.mjs') })
}

function preflight() {
  const problems = []
  if (!fs.existsSync(path.join(HERE, 'extension', 'service', 'index.js'))) {
    problems.push('缺少 extension/service/index.js')
  }
  if (!fs.existsSync(path.join(TESTS, 'security.mjs'))) {
    problems.push('缺少 extension/tests/security.mjs')
  }
  const apk = path.join(HERE, 'apk', 'todo-link-2.9.1.apk')
  if (!fs.existsSync(apk)) problems.push('缺少 apk/todo-link-2.9.1.apk')
  const major = Number(process.versions.node.split('.')[0])
  if (major < 18) problems.push(`需要 Node 18+，当前 ${process.version}`)
  return problems
}

const problems = preflight()
if (problems.length) {
  console.error('环境检查未通过：')
  for (const p of problems) console.error(' - ' + p)
  process.exit(1)
}

console.log('='.repeat(60))
console.log(' 审计修复验证包 · x-hub 待办同步')
console.log(` Node ${process.version} · ${process.platform}`)
console.log('='.repeat(60))

const results = []
for (const s of suites) {
  console.log(`\n>>> ${s.name}`)
  console.log('-'.repeat(60))
  const r = spawnSync(process.execPath, [s.file], { stdio: 'inherit', cwd: HERE })
  results.push({ name: s.name, code: r.status })
}

console.log('\n' + '='.repeat(60))
console.log(' 汇总')
console.log('='.repeat(60))
let failed = 0
for (const r of results) {
  const ok = r.code === 0
  if (!ok) failed++
  console.log(` ${ok ? '通过' : '失败'}  ${r.name}`)
}

if (failed) {
  console.log(`\n有 ${failed} 套未通过，详见上面的 ✗ 条目。`)
  process.exit(1)
}
console.log('\n全部通过。')
